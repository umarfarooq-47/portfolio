// ===== MOBILE MENU =====
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.querySelector(".nav-links");

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("active");
});

// Link dabane par menu band ho jaye
document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("active");
  });
});

// ===== SCROLL FADE-IN ANIMATION =====
const items = document.querySelectorAll(
  ".skill-card, .project-card, .timeline-item, .contact-card, .about-container"
);

items.forEach((item) => item.classList.add("hidden"));

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
      }
    });
  },
  { threshold: 0.15 }
);

items.forEach((item) => observer.observe(item));