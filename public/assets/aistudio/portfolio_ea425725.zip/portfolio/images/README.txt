Apni asli images (profile.jpg, gallery.png, timezone.png, social.png, expense.png) is folder mein rakhein.
